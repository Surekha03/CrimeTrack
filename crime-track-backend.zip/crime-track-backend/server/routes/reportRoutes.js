const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const { createReport, updateReportStatus } = require("../controllers/reportController");  // ✅ Ensure these are correctly imported

const router = express.Router();

router.post("/", protect, createReport); // ✅ Ensure function is defined
router.put("/:id/status", protect, updateReportStatus); // ✅ Ensure function is defined

module.exports = router;
