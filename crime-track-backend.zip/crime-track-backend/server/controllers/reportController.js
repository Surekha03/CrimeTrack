const asyncHandler = require("express-async-handler");

const createReport = asyncHandler(async (req, res) => {
    res.json({ message: "Crime report created successfully" });
});

const updateReportStatus = asyncHandler(async (req, res) => {
    res.json({ message: "Crime report status updated successfully" });
});

module.exports = { createReport, updateReportStatus };
