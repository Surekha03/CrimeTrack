const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const connectDB = require("./config/db");
const userRoutes = require("./routes/userRoutes"); // Ensure these exist
const reportRoutes = require("./routes/reportRoutes");

dotenv.config();
connectDB(); // Ensure MongoDB is connected

const app = express();
app.use(express.json()); // Allow JSON body parsing
app.use(cors());

// Define API routes
app.use("/api/users", userRoutes);
app.use("/api/reports", reportRoutes); 

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
